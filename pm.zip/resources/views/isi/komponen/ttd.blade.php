<div class="row mt-5">
    <div class="col-6">

    </div>
    <div class="col-6">
        <table align="center">
            <tr>
                <td class="text-center"> <b> Dumai, {{date('d')}} {{Fungsi::$bulan[date('n')]}} {{date('Y')}}</b></td>
            </tr>
            <tr>
            </tr>
             <tr>
                <td class="text-center">
                    <p class="m-0 p-0">{{session()->get('admin')->nama}}</p>
                </td>
            </tr>
            <tr>
                <td>
                    <br>
                    <br>
                    <br>
                </td>
            </tr>

           <tr>
               <td>
                   <hr class="border border-dark">
               </td>
           </tr>
        </table>
    </div>
</div>
