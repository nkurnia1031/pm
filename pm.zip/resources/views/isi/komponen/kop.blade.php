<div style="border-bottom: solid;">
    <div class="d-flex justify-content-start tes2 mt-3">
        <div class="mr-5">
            <img src="logo.jpg" width="200" alt="Logo">
        </div>
        <div class="ml-5 align-self-center text-center">
            <p class="m-0 p-0">
                <b class="text-dark" style="font-size: 25pt;">
                    SMP-IT PLUS BAZMA BRILLIANT
                </b>
            </p>
            <p class="m-0 p-0">
                <b class="text-dark" style="font-size: 25pt;">
                    AKREDITASI “A”
                </b>
            </p>
            <p class="m-0 p-0">
                <span class="text-dark" style="font-size: 12pt;">
                    Surat Izin Nomor : 01/IPSS/BPTPM/III/2014
                </span>
            </p>
            <p class="m-0 p-0">
                <span class="text-dark" style="font-size: 12pt;">
                    No.Telp/Hp. (0765) 44–3340 / 082388527766
                </span>
            </p>
            <p class="m-0 p-0">
                <span class="text-dark" style="font-size: 12pt;">
                    e-mail. <a href="mailto:smpitplus.bazmabrilliant@gmail.com">smpitplus.bazmabrilliant@gmail.com</a>
                </span>
            </p>
            <p class="m-0 p-0">
                <span class="text-dark" style="font-size: 12pt;">
                    Jl. Sekolah Komplek Perumahan Pertamina Bukit Datuk, Dumai – Riau
                </span>
            </p>
            <br>
        </div>
    </div>
    <div class="mx-5 px-5 justify-content-between d-flex text-justify">
        <span class="text-dark mr-auto" style="font-size: 12pt;">
            NPSN. 69838801
        </span>
        <span class="text-dark ml-auto" style="font-size: 12pt;">
            NSS. 20.2.09.06.07.001
        </span>
    </div>
</div>
