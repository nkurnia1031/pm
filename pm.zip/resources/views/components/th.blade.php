@foreach ($isi as $e)
@if ($e['tb'])
<th class="">{!!$e['label']!!}</th>
@endif
@endforeach
